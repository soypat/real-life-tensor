function [sig,N] = getbartensions(b,Fv)
%GETVIGATENSIONS devuelve tensiones maximas para unaviga

N=Fv(2);
A=b^2*pi/4;
sig=N/A;
end

