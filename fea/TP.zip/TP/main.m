%Retroexcavadora
%barras
%
%Tb

%T(phi)
%viga(E,I,L)

%vigota(E,A,I,L)
%Tvu(phi)

P=3200;
E=30e6;
h_nom=10;%in
b_nom=10;
Fa=-P*15/16;
Fb=-Fa;
elementos=[1 2 3 4 5 6;
    1 2 3 10 11 12;
    7 8 9 10 11 12;
    4 5 6 7 8 9;
    7 8 9 13 14 15;
    10 11 12 13 14 15;
    13 14 15 16 17 18;
    16 17 18 19 20 21;
    16 17 18 22 23 24];

L1=20;
L2=16;
L3 = dist(20,8);
L4=8;
L5=dist(15,5);
L6=dist(7,15);
L7=dist(16,12);
L8=dist(6,24);
L9=dist(30,30);
phi1=0;
phi2=-90;
phi3=180+atand(8/20);
phi4=-90;
phi5=180+atand(15/5);
phi6=-atand(7/15);
phi7=-atand(12/16);
phi8=-atand(21/6);
phi9=-atand(1);
Iz=@(b,h) b*h^3/12;
Ar=@(b,h) b*h;
barras=[1 2 3 9];

h=h_nom;
b=b_nom;
Ne=9;
ndof=3;
N=8;
Ndof=ndof*N;
kG=zeros(Ndof);

for i=1:9
    L=eval(sprintf('L%0.0f',i));
    A=Ar(h,h);
    phi=eval(sprintf('phi%0.0f',i));
    if sum(ismember(barras,i))>0%si es barra corre
         klocal=Kb(E,A,L,phi);
%          klocal=Kv(E,A,I,L,phi);
         kG(elementos(i,:),elementos(i,:))=kG(elementos(i,:),elementos(i,:))+klocal;
    elseif i==2
        Eeffectiva=E*10;
%       klocal=Kb(Eeffectiva,A,L,phi);
        klocal=Kv(E,A,I,L,phi);
        kG(elementos(i,:),elementos(i,:))=kG(elementos(i,:),elementos(i,:))+klocal;
    else
        I=Iz(h,h);
        klocal=Kv(E,A,I,L,phi);
        kG(elementos(i,:),elementos(i,:))=kG(elementos(i,:),elementos(i,:))+klocal;
    end
end

CB=false(Ndof,1);
CB(elementos(8,4:5))=true;
CB(elementos(9,4:5))=true;

R=zeros(Ndof,1);
R(elementos(1,1:2))=[Fa -P/2];
R(elementos(2,4:5))=[Fb -P/2];

F=R(~CB);
K=kG(~CB,~CB);

U=K\F;
%IDEAS


% campo1='nom'; %nombre del primer campo
% valores1={'IRAM IAS 4340 TR','IRAM IAS 4340 TR2'};
% campo2='E';%Modulo de Young en MPa
% valores2=[200000,200001];
% campo3='poisson';
% valores3=[.29,.29];
% campo4='HB';   %dureza Brinell
% valores4=[500,500];
% campo5='costo';
% valores5=[1,1];
% 
% 
% 
% mat=struct(campo1,valores1,campo2,valores2,campo3,valores3...
%     ,campo4,valores4,campo5,valores5 );
% clearvars campo1 campo2 campo3 campo4 campo5
% clearvars valores1 valores2 valores3 valores4 valores5
% %Se accede a los campos de la siguiente forma
% % mat(1).nom >>'AISI1040'
% % mat(2).nom >>'Martensitico 1030'
% % mat(1).poisson >> 0.25