function [dist] = dist(a,b)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
dist=sqrt(a^2+b^2);
end

