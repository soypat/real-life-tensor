%% Grados de libertad
% Nodo   n     DOF   
%  1     1 --> U1
%        2 --> V1
%        3 --> tita1
%  2     4 --> U2
%        5 --> V2
%        6 --> tita21
%        7 --> tita22
%  3     8 --> U3
%        9 --> V3
%       10 --> tita3
%  4    11 --> U4
%       12 --> V4
%       13 --> tita43
%       14 --> tita44
%  5    15 --> U5
%       16 --> V5
%       17 --> tita5
%  6    18 --> U6
%       19 --> V6
%       20 --> tita65
%       21 --> tita66
%  7    22 --> U7
%       23 --> V7
%       24 --> tita7
%% Para cada elemento
% Elem 1 [U1 V1 tita1 U2 V2 tita21]
% Elem 2 [U2 V2 tita22 U3 V3 tita3]
% Elem 3 [U2 V2 tita21 U4 V4 tita43]
% Elem 4 [U4 V4 tita44 U5 V5 tita5]
% Elem 5 [U5 V5 tita5 U6 V6 tita65]
% Elem 6 [U6 V6 tita66 U7 V7 tita7]