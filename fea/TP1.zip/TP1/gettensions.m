function [sig,tau] = getvigatensions(b,h,Fv)
%GETVIGATENSIONS d
sigN=
end

