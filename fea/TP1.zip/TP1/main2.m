%Main v2
%G2D-FEAS
%General two dimensional Finite Element Analysis Script

%Preparation:
% enunciado
% enunciado
test
ndof=3;
empotramientos=[];
%Actual code
Le=zeros(Ne,1);
phide=zeros(Ne,1);
Ndof=N*ndof;

verify(nod,elenod);

for i = 1:Ne
    nodestart=elenod(i,1);
    nodeend=elenod(i,2);
    lx=nod(nodeend,1)-nod(nodestart,1);
    ly=nod(nodeend,2)-nod(nodestart,2);
    Le(i)=sqrt(lx^2+ly^2);
    phide(i)=atan2d(ly,lx);%angulo en degrees
end

kG=zeros(Ndof);
losklocales={};
loskrotados={};

try %Generac�n del vector CB. Asegura correcta generaci�n si el usuario tira fruta
    [a, b]=size(CB);
    if (a==1 && b==Ndof)
        CB=CB';
    elseif (a~=Ndof || ~islogical(CB))
        warning('Condiciones de borde no tienen tama�o requerido o no es matriz logica. Usar false().\nImponiendo condiciones de borde sugeridas...')
        CB=false(Ndof,1);
    end
catch e
    warning('Imponiendo condiciones de borde sugeridas debido a error relacionado con condiciones de borde...\nMensaje:%s',e.message)
    CB=false(Ndof,1);
end

for i=1:Ne %ASSEMBLY
    switch eletype(i)
        case 1
            kbarra=Kb(Ee(i),Ae(i),Le(i),phide(i));
            klocal=zeros(6);
            klocal([1 2 4 5],[1 2 4 5])=kbarra;
            T=Tbu(phide(i));
            kbarrarotada=T*kbarra*T';
            klocalrotada=zeros(6);
            klocal([1 2 4 5],[1 2 4 5])=kbarrarotada;
            CB(elementos(i,ndof))=true;
            CB(elementos(i,2*ndof))=true;
        case 2
            klocal=Kv(Ee(i),Ae(i),Ie(i),Le(i));
            T=Tvu(phide(i));
            klocalrotada=T'*klocal*T;
            
        case 3
            klocal=vigabisagrada(Ee(i),Ae(i),Ie(i),Le(i),1);
            T=Tvu(phide(i));
            klocalrotada=T'*klocal*T;
        case 4
            klocal=vigabisagrada(Ee(i),Ae(i),Ie(i),Le(i),0);
            Tvu(phide(i));
            klocalrotada=T'*klocal*T;
    end
     kG(elementos(i,:),elementos(i,:))=kG(elementos(i,:),elementos(i,:))+klocalrotada;
     loskrotados=[loskrotados klocalrotada];%Guardo cada krotado
     losklocales=[losklocales klocal];
end



for i=1:length(apoyos_simples)
    n=apoyos_simples(i);
    CB([n*ndof-2 n*ndof-1])=true;
end

Kr=kG(~CB,~CB);
F=R(~CB);
U=Kr\F; %OBTUVE DESPLAZANIETOS

D=regendesplazamientos(U,CB);


forzas={}; %Genero estructura con fuerzas sobre cada elemento
for i = 1:Ne
%     klocal=loskrotados{i};
    klocal=loskrotados{i};
    ulocal=D(elementos(i,:));
    T=Tvu(phide(i));
    flocal=klocal*ulocal;
    forzas=[forzas flocal];
end
% GrafitodoF(Le(6),Le(7),Le(8),forzas{6},forzas{7},forzas{8});
graficapoco(nod,elenod,eletype,Ie);

try
    if ~isempty(vigasinteresantes)
        grafisuficiente(Le(vigasinteresantes),phide(vigasinteresantes),forzas{vigasinteresantes})
    end
catch
end

% i=6;
Calcutodo(Ae(i),Ie(i),ce(i),be(i),Ee(i),forzas{i});