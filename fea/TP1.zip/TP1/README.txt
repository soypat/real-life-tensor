Welcome to G2DFEAS

Modify problem in enunciado.m
run main2 to solve.

Returns elemento number with danger factor (variable/admissible_value_for_variable)*safety_factor in two rows
tension as second row, pandeo (buckling) as third row.


